﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GalaxyCatalog.Modals
{
    public interface ICountList
    {     

      int GetActiveInstances();

       string GetInnerList(string x);

    }
}
